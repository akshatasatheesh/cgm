# -*- coding: utf-8 -*-
"""
Created on Wed Feb  8 15:15:00 2023

@author: zhangfy
"""
import numpy as np


def rmse(y_true, y_pred):
    RMSE = np.linalg.norm(y_pred - y_true) / np.sqrt(y_true.shape[0])
    return RMSE


def corr(y_true, y_pred):
    CORR = np.corrcoef(y_pred, y_true)[0,1]
    return CORR


def mard(y_true, y_pred):
    MARD = np.sum(np.abs(y_pred-y_true)/y_true)/len(y_true)
    return MARD


def mard2(y_true, y_pred):
    MARD = np.sum(np.abs(y_pred-y_true))/len(y_true)
    return MARD


def r2(y_true, y_pred):
    R2 = 1 - np.sum((y_pred-y_true)**2)/np.sum((y_true-np.mean(y_true))**2)
    return R2


def print_metrics(y_true, y_pred):
    print("RMSE:",np.round(rmse(y_true,y_pred),2))
    print("PCC:",np.round(corr(y_true,y_pred),3))
    print("MARD:",np.round(mard(y_true,y_pred),3))
    print("R2:",np.round(r2(y_true,y_pred),3))


def get_metrics(y_true, y_pred):
    return rmse(y_true, y_pred), corr(y_true, y_pred), mard(y_true, y_pred), r2(y_true, y_pred)


def prediction_interval(y_true, y_pred):
    """Return the prediction interval with 95% confidence"""
    sum_squared_error = np.sum((y_pred-y_true)**2)
    interval = 1.96*np.sqrt(1/(len(y_true)-2)*sum_squared_error)
    return interval
